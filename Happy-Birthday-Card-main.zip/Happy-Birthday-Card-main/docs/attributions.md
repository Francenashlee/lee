# Atributions

- <a href='https://www.freepik.com/vectors/pattern'>Pattern vector created by mokoland - www.freepik.com</a>
- <a href='https://www.freepik.com/vectors/christmas'>Christmas vector created by freepik - www.freepik.com</a>
- <a href='https://www.freepik.com/vectors/background'>Background vector created by brgfx - www.freepik.com</a>
- <a href='https://www.freepik.com/vectors/halloween'>Halloween vector created by vectorpouch - www.freepik.com</a>

- The favicon was generated using the following graphics from Twitter Twemoji:

  - Graphics Title: 1f382.svg
  - [Graphics Author: Copyright 2020 Twitter, Inc and other contributors](https://github.com/twitter/twemoji)
  - Graphics Source: [https://github.com/twitter/twemoji/blob/master/assets/svg/1f382.svg](https://github.com/twitter/twemoji/blob/master/assets/svg/1f382.svg)
  - [Graphics License: CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/)

---

<div align="center">Made with 💖 by Anshuman Mahato</div>
